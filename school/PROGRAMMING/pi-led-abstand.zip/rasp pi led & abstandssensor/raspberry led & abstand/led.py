#
# Copyright Robin Brämer 2020
# https://github.com/robinbraemer
#

import RPi.GPIO as IO
import time

# Settings
red = 40
yellow = 13
green = 33
allPins = [red,yellow,green]

# Setup
def setup():
    IO.setmode(IO.BOARD)
    IO.setwarnings(False)
    IO.setup(yellow, IO.OUT)
    IO.setup(green, IO.OUT)
    IO.setup(red, IO.OUT)

#
# Helpers
#
def toggle(pin: int=None, state: int=IO.LOW):
    if pin is None:
        for pin in allPins:
            toggle(pin, state)
        return
    IO.output(pin, state)
    
def on(pin=None):
    toggle(pin, IO.HIGH)
    
def off(pin=None):
    toggle(pin, IO.LOW)
    
def sleep(t: float):
    time.sleep(t)


#
# Algorithms
#
def order(waitTotal: float, pins: list=allPins):
    wait = waitTotal / len(pins)
    pinBefore = None
    for pin in pins:
        off(pinBefore)
        on(pin)
        pinBefore = pin
        sleep(wait)
    off(pinBefore)
    
def disco():
    wait=0.5
    while True:
        for x in range(5):
            order(waitTotal=wait,pins=[yellow,green,red,green])
        wait = wait - 0.1
        if wait < 0:
            break
    on()
    sleep(3)
    off()

def trafficLight():
    off()
    on(red)
    sleep(2)
    on(yellow)
    sleep(1)
    off(red)
    off(yellow)
    on(green)
    sleep(2)
    on(yellow)
    off(green)
    sleep(2)
    off(yellow)
    on(red)
