#
# Copyright Robin Brämer 2020
# https://github.com/robinbraemer
#

from led import *
from abstand import *
import RPi.GPIO as IO

    
setup()

while True:
    a = abstand()
    
    if a < 1:
        continue
    
    ticker = a / 800
    sleep(ticker)
    off()
    sleep(ticker)
    on()
