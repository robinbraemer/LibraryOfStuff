/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong;

import de.robinbraemer.bluej.pingpong.engine.Game;
import de.robinbraemer.bluej.pingpong.engine.Rectangle;

import java.awt.*;

public class PingPong extends Game {
    
    private Ball ball;
    
    private Player playerLeft;
    private Player playerRight;
    
    private Rectangle centerLine;
    
    private Rectangle borderTop;
    private Rectangle borderBottom;
    
    public static final Color BALL_COLOR = Color.YELLOW;
    public static final Color GOAL_COLOR = Color.GREEN;
    
    public static final int RACKET_THICKNESS = 25;
    public static final int BORDER_THICKNESS = 4;
    public static final Color BORDER_COLOR = Color.PINK;
    
    // reset game key
    public static final int KEY_N = 13;
    
    // player left
    public static final int KEY_W = 22;
    public static final int KEY_A = 0;
    public static final int KEY_S = 18;
    public static final int KEY_D = 3;
    
    // player right
    public static final int KEY_UP = 26;
    public static final int KEY_LEFT = 29;
    public static final int KEY_DOWN = 28;
    public static final int KEY_RIGHT = 27;
    
    
    public PingPong( int width, int height, int tickSpeed ) {
        super( width, height, true, true, false, tickSpeed );
        
        // borders
        borderTop = new Rectangle( getWidth(), BORDER_THICKNESS, new Point( getWidth() / 2, getHeight() ), BORDER_COLOR );
        borderBottom = new Rectangle( getWidth(), BORDER_THICKNESS, new Point( getWidth() / 2, 0 ), BORDER_COLOR );
        
        // cool center line
        centerLine = new Rectangle( 4, super.getHeight(), new Point( super.getWidth() / 2, super.getHeight() / 2 ), Color.WHITE );
        
        // ball
        ball = new Ball( 15, new Point( getWidth() / 2, getHeight() / 2 ), BALL_COLOR );
        
        // players (racket, goal)
        playerLeft = new Player(
                new Racket( this, RACKET_THICKNESS, 100, new Point( RACKET_THICKNESS / 2, super.getHeight() / 2 ), Color.BLUE ),
                new Rectangle( BORDER_THICKNESS, getHeight(), new Point( 0, getHeight() / 2 ), GOAL_COLOR )
        );
        playerRight = new Player(
                new Racket( this, RACKET_THICKNESS, 100, new Point( super.getWidth() - RACKET_THICKNESS / 2, super.getHeight() / 2 ), Color.RED ),
                new Rectangle( BORDER_THICKNESS, getHeight(), new Point( getWidth(), getHeight() / 2 ), GOAL_COLOR )
        );
        
        // only start ticker after initialization complete
        super.startTicker();
    }
    
    @Override
    public void tick( ) {
        // ball reflections & ball hit a goal
        if ( ball.cuts( borderTop ) || ball.cuts( borderBottom ) ) {
            ball.invertDeltaY();
        } else if ( ball.cuts( playerLeft.getRacket() ) || ball.cuts( playerRight.getRacket() ) ) {
            if ( ball.cuts( playerLeft.getRacket() ) ) {
                // to check that ball is at top/bottom of racket
                int halfRacket = playerLeft.getRacket().getHeight() / 2;
                // ball reflect at top/bottom of racket
                racketReflectBall( halfRacket, playerLeft );
            } else {
                // to check that ball is at top/bottom of racket
                int halfRacket = playerRight.getRacket().getHeight() / 2;
                // ball reflect at top/bottom of racket
                racketReflectBall( halfRacket, playerRight );
            }
        } else if ( ball.cuts( playerLeft.getGoal() ) || ball.cuts( playerRight.getGoal() ) ) {
            super.pauseTicker();
            // add score to player
            if ( ball.cuts( playerLeft.getGoal() ) )
                super.setRightScore( super.getRightScore() + 1 );
            else super.setLeftScore( super.getRightScore() + 1 );
            ball.reset();
            playerLeft.getRacket().reset();
            playerRight.getRacket().reset();
            super.startTicker();
        }
        
        ball.move();
        
        // stop racket at top border
        stopRacketAtBorder( playerLeft.getRacket() );
        stopRacketAtBorder( playerRight.getRacket() );
        
        // stop racket at center line
        stopRacketAtCenter( playerLeft );
        stopRacketAtCenter( playerRight );
        
        // stop racket at goal line
        stopRacketAtGoal( playerLeft );
        stopRacketAtGoal( playerRight );
        
        playerLeft.getRacket().move();
        playerRight.getRacket().move();
    }
    
    private void stopRacketAtGoal( Player p ) {
        if ( p.getRacket().cuts( p.getGoal() ) )
            if ( p.equals( playerLeft ) )
                p.getRacket().stop( Racket.STOP_LEFT_GOAL );
            else p.getRacket().stop( Racket.STOP_RIGHT_GOAL );
    }
    
    private void stopRacketAtCenter( Player p ) {
        if ( p.getRacket().cuts( this.centerLine ) )
            if ( p.equals( playerLeft ) )
                p.getRacket().stop( Racket.STOP_CENTER_LEFT );
            else p.getRacket().stop( Racket.STOP_CENTER_RIGHT );
    }
    
    private void stopRacketAtBorder( Racket r ) {
        if ( r.cuts( this.borderTop ) )
            r.stop( Racket.STOP_TOP );
        else if ( r.cuts( this.borderBottom ) )
            r.stop( Racket.STOP_BOTTOM );
    }
    
    private void racketReflectBall( int halfRacket, Player p ) {
        // for a smash ball
        if ( p.getRacket().getDeltaX() > 0 ) {
            ball.increaseDeltaX();
        } else if ( p.getRacket().getDeltaX() < 0 ) {
            ball.decreaseDeltaX();
        }
        
        if ( ball.distanceY( p.getRacket() ) < -halfRacket ) { // bottom of racket
            ball.decreaseDeltaY();
        } else if ( ball.distanceY( p.getRacket() ) > halfRacket ) { // top of racket
            ball.increaseDeltaY();
        } else {
            // ball reflect normally
            ball.invertDeltaX();
            // fix when racket moves towards ball
            ball.move();
            ball.move();
        }
    }
    
    @Override
    public void tasteReagieren( int keyId ) {
        switch ( keyId ) {
            case KEY_W:
                playerLeft.getRacket().decreaseDeltaY();
                break;
            case KEY_S:
                playerLeft.getRacket().increaseDeltaY();
                break;
            case KEY_A:
                playerLeft.getRacket().setDeltaX( -1 );
                break;
            case KEY_D:
                playerLeft.getRacket().setDeltaX( 1 );
                break;
            
            case KEY_UP:
                playerRight.getRacket().decreaseDeltaY();
                break;
            case KEY_DOWN:
                playerRight.getRacket().increaseDeltaY();
                break;
            case KEY_LEFT:
                playerRight.getRacket().setDeltaX( -1 );
                break;
            case KEY_RIGHT:
                playerRight.getRacket().setDeltaX( 1 );
                break;
            
            case KEY_N:
                this.reset();
        }
    }
    
    /**
     * Reset whole game.
     */
    public void reset( ) {
        super.startTicker();
        ball.reset();
        playerRight.reset();
        playerLeft.reset();
        super.setLeftScore( 0 );
        super.setRightScore( 0 );
    }
    
    public Player getPlayerLeft( ) {
        return playerLeft;
    }
    
    public Player getPlayerRight( ) {
        return playerRight;
    }
    
    public Rectangle getCenterLine( ) {
        return centerLine;
    }
}
