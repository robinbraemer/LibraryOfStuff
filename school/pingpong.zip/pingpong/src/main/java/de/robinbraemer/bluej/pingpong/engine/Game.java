/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong.engine;

import ea.Bild;
import ea.edu.AnzeigeE;

public class Game {
    
    /**
     * Mainframe
     */
    private static AnzeigeE frame;
    private int scoreLeft = 0;
    private int scoreRight = 0;
    
    private int width;
    private int height;
    private int tickSpeed;
    
    public Game( int width, int height,
                 boolean showLeftScore, boolean showRightScore,
                 boolean showMouse,
                 int tickSpeed
    ) {
        this.tickSpeed = tickSpeed;
        this.width = width;
        this.height = height;
        frame = new AnzeigeE( width, height );
        
        // show scores or not
        frame.punkteLinksSichtbarSetzen( showLeftScore );
        frame.punkteRechtsSichtbarSetzen( showRightScore );
        
        // activate keyboard
        frame.tastenReagierbarAnmelden( this );
        
        // activate mouse
        if ( showMouse ) {
            frame.klickReagierbarAnmelden( this, true );
        }
    }
    
    public void startTicker( ) {
        frame.tickerAnmelden( this, tickSpeed );
    }
    
    public void pauseTicker( ) {
        frame.tickerAbmelden( this );
    }
    
    /**
     * Run every tick.
     * IMPORTANT: don't change the method name since bluej needs it like that
     */
    public void tick( ) {
        System.out.println( "tick!" );
    }
    
    /**
     * Run on every mouse click.
     * IMPORTANT: don't change the method name since bluej needs it like that
     *
     * @param x x-coordinate
     * @param y y-coordinate
     */
    public void klickReagieren( int x, int y ) {
        System.out.println( "Click (" + x + ", " + y + ")" );
    }
    
    
    /**
     * Run on every key pressed.
     * IMPORTANT: don't change the method name since bluej needs it like that
     *
     * @param keyId Pressed key identifier. Get more info via google.com :)
     */
    public void tasteReagieren( int keyId ) {
        System.out.println( "Key " + keyId );
    }
    
    
    /**
     * Set left score.
     *
     * @param score New score
     */
    public void setLeftScore( int score ) {
        this.scoreLeft = score;
        frame.punkteLinksSetzen( score );
    }
    
    /**
     * Set right score.
     *
     * @param score New score
     */
    public void setRightScore( int score ) {
        this.scoreRight = score;
        frame.punkteRechtsSetzen( score );
    }
    
    /**
     * Get left score.
     *
     * @return left score
     */
    public int getLeftScore( ) {
        return scoreLeft;
    }
    
    /**
     * Get right score.
     *
     * @return right score
     */
    public int getRightScore( ) {
        return scoreRight;
    }
    
    /**
     * Change display color of scores.
     *
     * @param color New color
     */
    public void setScoreColor( String color ) {
        frame.setzeFarbePunktestand( color );
    }
    
    
    /**
     * Set background image of game frame.
     *
     * @param path Path of image file.
     */
    public void setBackgroundImage( String path ) {
        ea.edu.FensterE.getFenster().hintergrundSetzen( new Bild( 0, 0, path ) );
    }
    
    
    public int getWidth( ) {
        return width;
    }
    
    public int getHeight( ) {
        return height;
    }
}
