/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong;

import javax.swing.*;

public class Main {
    
    public static void main( String[] args ) {
        Object[] opts = {"Start"};
        JOptionPane.showOptionDialog(
                null,
                "All rights reserved by Robin Brämer (c) 2019\n" +
                        "Press 'Start' to play... :)",
                "Ping Pong by Robin Brämer (c)",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opts, opts[0]
        );
        
        PingPong pp = new PingPong( 808, 629, 10 );
        
        //GregorianCalendar bd = new GregorianCalendar( 2001, 3, 28, 0, 0, 0 );
        //Duration d = Duration.ofMillis( System.currentTimeMillis() - bd.getTimeInMillis() );
        //System.out.println( d.toDays() / 365 );
    }
    
    private static void infoBox( String msg, String title ) {
        JOptionPane.showMessageDialog(
                null, msg,
                "InfoBox: " + title,
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}
