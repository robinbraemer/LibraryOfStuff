/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong.utils;

import java.util.Random;

public class Utils {
    
    private static final Random random = new Random();
    
    public static int randomInt( int start, int end ) {
        return random.nextInt( end - start + 1 ) + start;
    }
}
