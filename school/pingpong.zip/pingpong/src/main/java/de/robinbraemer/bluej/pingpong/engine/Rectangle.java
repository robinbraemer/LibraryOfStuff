/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong.engine;

import ea.edu.RechteckE;

import java.awt.*;

public class Rectangle extends RechteckE {
    
    public Rectangle( ) {
        this( 200, 130, new Point( 250, 250 ), Color.RED );
    }
    
    public Rectangle( int width, int height, Point midpoint, Color color ) {
        super.masseSetzen( width, height );
        super.farbeSetzen( color );
        super.sichtbarSetzen( true );
        this.setMidpoint( midpoint );
    }
    
    /**
     * Whether the circle cuts a bluej ea.Raum or not.
     *
     * @param r the ea.Raum to test
     * @return true if it cuts
     */
    public boolean cuts( ea.Raum r ) {
        return super.schneidet( r );
    }
    
    public void shift( int deltaX, int deltaY ) {
        this.verschieben( deltaX, deltaY );
    }
    
    public Point getMidpoint( ) {
        return new Point( super.mittelPunkt().x(), super.mittelPunkt().y() );
    }
    
    public int getWidth( ) {
        return (int) super.getBreite();
    }
    
    public int getHeight( ) {
        return (int) super.getHoehe();
    }
    
    public void setMidpoint( Point midpoint ) {
        super.mittelpunktSetzen( (int) midpoint.getX(), (int) midpoint.getY() );
    }
    public void setMidpoint( int x, int y ) {
        super.mittelpunktSetzen( x, y );
    }
}
