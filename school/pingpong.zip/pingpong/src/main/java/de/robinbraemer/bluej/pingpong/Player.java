/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong;

import de.robinbraemer.bluej.pingpong.engine.Rectangle;

public class Player {
    
    private Racket racket;
    private Rectangle goal;
    
    public Player( Racket racket, Rectangle goal ) {
        this.racket = racket;
        this.goal = goal;
    }
    
    public Racket getRacket( ) {
        return racket;
    }
    
    public Rectangle getGoal( ) {
        return goal;
    }
    
    public void reset( ) {
        racket.reset();
    }
}
