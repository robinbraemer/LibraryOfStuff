/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong;

import de.robinbraemer.bluej.pingpong.engine.Rectangle;

import java.awt.*;

public class Racket extends Rectangle {
    
    private int deltaX = 0;
    private int deltaY = 0;
    
    private Point reset;
    
    private PingPong pingPong;
    
    Racket( PingPong pingPong, int width, int height, Point midpoint, Color color ) {
        super( width, height, midpoint, color );
        this.reset = midpoint;
        this.pingPong = pingPong;
    }
    
    public void move( ) {
        super.shift( deltaX, deltaY );
    }
    
    public void increaseDeltaY( ) {
        deltaY += 1;
    }
    
    public void decreaseDeltaY( ) {
        deltaY -= 1;
    }
    
    public void reset( ) {
        super.setMidpoint( reset );
        deltaX = 0;
        if ( deltaY == 0 ) // prevent 0 division
            deltaY = 1;
        deltaY = deltaY / Math.abs( deltaY );
    }
    
    public static final int STOP_TOP = 1;
    public static final int STOP_BOTTOM = 2;
    public static final int STOP_CENTER_LEFT = 3;
    public static final int STOP_CENTER_RIGHT = 4;
    public static final int STOP_LEFT_GOAL = 5;
    public static final int STOP_RIGHT_GOAL = 6;
    
    
    /**
     * Stop the racket that it can't move out of its desired area.
     *
     * @param placeId use STOP_* constant variables
     */
    public void stop( int placeId ) {
        if ( placeId == STOP_BOTTOM ) { // stop racket at bottom border
            // y = half Racket height + Game border thickness + 1
            int y = getHeight() / 2 + PingPong.BORDER_THICKNESS + 1;
            super.setMidpoint( (int) super.getMidpoint().getX(), y );
            deltaY = 0;
        } else if ( placeId == STOP_TOP ) { // stop racket at top border
            // y = game frame height - half racket height - game border thickness -1
            int y = pingPong.getHeight() - getHeight() / 2 - PingPong.BORDER_THICKNESS - 1;
            super.setMidpoint( (int) super.getMidpoint().getX(), y );
            deltaY = 0;
        } else if ( placeId == STOP_CENTER_LEFT ) { // stop racket at left side of center line
            // x = half game frame - half racket width - half center line width - 1
            int x = pingPong.getWidth() / 2 - getWidth() / 2 - pingPong.getCenterLine().getWidth() / 2 - 1;
            super.setMidpoint( x, (int) super.getMidpoint().getY() );
            deltaX = 0;
        } else if ( placeId == STOP_CENTER_RIGHT ) { // stop racket at right side of center line
            // x = half game frame + half racket width + half center line width + 1
            int x = pingPong.getWidth() / 2 + getWidth() / 2 + pingPong.getCenterLine().getWidth() / 2 + 1;
            super.setMidpoint( x, (int) super.getMidpoint().getY() );
            deltaX = 0;
        } else if ( placeId == STOP_LEFT_GOAL ) { // stop racket at goal of left player
            // x = half of goal + half of racket width + 1
            int x = pingPong.getPlayerLeft().getGoal().getWidth() / 2 + pingPong.getPlayerLeft().getRacket().getWidth() / 2 + 1;
            super.setMidpoint( x, (int) super.getMidpoint().getY() );
            deltaX = 0;
        } else if ( placeId == STOP_RIGHT_GOAL ) { // stop racket at goal of right player
            // x = game width - half of goal - half of racket width - 1
            int x = pingPong.getWidth() - pingPong.getPlayerRight().getGoal().getWidth() / 2 - pingPong.getPlayerRight().getRacket().getWidth() / 2 - 1;
            super.setMidpoint( x, (int) super.getMidpoint().getY() );
            deltaX = 0;
        }
    }
    
    public void setDeltaX( int deltaX ) {
        this.deltaX = deltaX;
    }
    
    public void setDeltaY( int deltaY ) {
        this.deltaY = deltaY;
    }
    
    public int getDeltaX( ) {
        return deltaX;
    }
}
