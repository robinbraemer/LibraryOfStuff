/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong.engine;

import ea.edu.KreisE;

import java.awt.*;

public class Circle extends KreisE {
    
    public Circle( int radius, Point midpoint, Color color ) {
        super.farbeSetzen( color );
        super.radiusSetzen( radius );
        super.mittelpunktSetzen( (int) midpoint.getX(), (int) midpoint.getY() );
        super.sichtbarSetzen( true );
    }
    
    public void shift( int deltaX, int deltaY ) {
        this.verschieben( deltaX, deltaY );
    }
    
    /**
     * Whether the circle cuts a bluej ea.Raum or not.
     *
     * @param r the ea.Raum to test
     * @return true if it cuts
     */
    public boolean cuts( ea.Raum r ) {
        return super.schneidet( r );
    }
    
    public void setMidpoint( Point midpoint ) {
        super.mittelpunktSetzen( (int) midpoint.getX(), (int) midpoint.getY() );
    }
    
    public void setMidpoint( int x, int y ) {
        super.mittelpunktSetzen( x, y );
    }
    
    public int distanceX( ea.Raum r ) {
        return this.mittelPunkt().x() - r.mittelPunkt().x();
    }
    
    public int distanceY( ea.Raum r ) {
        return this.mittelPunkt().y() - r.mittelPunkt().y();
    }
}
