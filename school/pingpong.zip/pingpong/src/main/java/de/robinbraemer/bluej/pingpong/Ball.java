/*
 * Copyright (c) Robin Brämer. All rights reserved.
 * Use is subject to license terms.
 */
package de.robinbraemer.bluej.pingpong;

import de.robinbraemer.bluej.pingpong.engine.Circle;

import java.awt.*;

public class Ball extends Circle {
    
    private int deltaX = 1;
    private int deltaY = 0;
    
    private Point reset;
    
    Ball( int radius, Point midpoint, Color color ) {
        super( radius, midpoint, color );
        this.reset = midpoint;
    }
    
    public void move( ) {
        super.shift( deltaX, deltaY );
    }
    
    public void increaseDeltaX( ) {
        // for a smash ball
        if ( deltaX > 0 )
            deltaX += 1;
        else if ( deltaX < 0 )
            deltaX -= 1;
    }
    
    public void increaseDeltaY( ) {
        deltaY += 1;
    }
    
    public void decreaseDeltaX( ) {
        // for a smash ball
        if ( deltaX > 1 )
            deltaX -= 1;
        else if ( deltaX < -1 )
            deltaX += 1;
    }
    
    public void decreaseDeltaY( ) {
        deltaY -= 1;
    }
    
    public void invertDeltaX( ) {
        deltaX = -deltaX;
    }
    
    public void invertDeltaY( ) {
        deltaY = -deltaY;
    }
    
    public void reset( ) {
        this.setMidpoint( reset );
        // prevent 0 division
        if ( deltaY == 0 ) deltaY = 1;
        if ( deltaX == 0 ) deltaX = 1;
        // reset delta to 1, but not reset the direction
        this.deltaX = this.deltaX / Math.abs( this.deltaX );
        this.deltaY = this.deltaY / Math.abs( this.deltaY );
    }
}
